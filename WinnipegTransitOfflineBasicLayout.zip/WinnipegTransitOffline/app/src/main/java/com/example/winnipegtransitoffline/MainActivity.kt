package com.example.winnipegtransitoffline

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.winnipegtransitoffline.destinations.Destination
import com.example.winnipegtransitoffline.navigation.BottomNav
import com.example.winnipegtransitoffline.screens.MapScreen
import com.example.winnipegtransitoffline.screens.PlanRouteScreen
import com.example.winnipegtransitoffline.screens.SearchScreen
import com.example.winnipegtransitoffline.ui.theme.WinnipegTransitOfflineTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WinnipegTransitOfflineTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    val navController = rememberNavController()
                    TransitApp(
                        navController = navController,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun TransitApp(navController: NavHostController, modifier: Modifier = Modifier) {
    Scaffold (
        bottomBar = {BottomNav(navController = navController)}
    ) { paddingValues ->
        NavHost(
            navController = navController as NavHostController,
            startDestination = Destination.Map.route
        ) {
            composable(Destination.Map.route) {
                MapScreen(modifier = Modifier.padding(paddingValues))
            }
            composable(Destination.PlanRoute.route) {
                PlanRouteScreen(modifier = Modifier.padding(paddingValues))
            }
            composable(Destination.Search.route) {
                SearchScreen(modifier = Modifier.padding(paddingValues))
            }
        }
    }
}