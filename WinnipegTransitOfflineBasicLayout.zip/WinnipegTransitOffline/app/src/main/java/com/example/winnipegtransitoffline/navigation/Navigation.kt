package com.example.winnipegtransitoffline.navigation


import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import com.example.winnipegtransitoffline.destinations.Destination

@Composable
fun BottomNav(navController: NavController) {
    NavigationBar {
        val navBackStackEntry = navController.currentBackStackEntry
        val currentDestination = navBackStackEntry?.destination

        NavigationBarItem(
            selected = currentDestination?.route == Destination.Map.route,
            onClick = { navController.navigate(Destination.Map.route) {
                popUpTo(Destination.Map.route)
                launchSingleTop = true
            }},
            icon = {},
            label = { Text(text = Destination.Map.route)}
        )
        NavigationBarItem(
            selected = currentDestination?.route == Destination.PlanRoute.route,
            onClick = { navController.navigate(Destination.PlanRoute.route) {
                popUpTo(Destination.PlanRoute.route)
                launchSingleTop = true
            }},
            icon = {},
            label = { Text(text = "plan route")}
        )
        NavigationBarItem(
            selected = currentDestination?.route == Destination.Search.route,
            onClick = { navController.navigate(Destination.Search.route) {
                popUpTo(Destination.Search.route)
                launchSingleTop = true
            }},
            icon = {},
            label = { Text(text = Destination.Search.route)}
        )
    }
}