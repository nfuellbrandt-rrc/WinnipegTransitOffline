package com.example.winnipegtransitoffline.destinations

sealed class Destination(val route: String) {
    object Map : Destination("map")
    object PlanRoute : Destination("plan_route")
    object Search : Destination("search")
    object Route : Destination("route") {
        fun createRoute(routeID: String?) = "route/$routeID"
    }
    object Stop : Destination("stop/{stopID}") {
        fun createRoute(stopID: Int?) = "stop/$stopID"
    }
}